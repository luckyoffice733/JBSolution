package com.training.jb.groceryrecepit;

public class Grocery {
	String fruit;
    double price, total;
	public Grocery(String fruit, double price, double total) {
		super();
		this.fruit = fruit;
		this.price = price;
		this.total = total;
	}


}
