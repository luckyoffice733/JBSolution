package com.training.jb.groceryrecepit;

import java.util.List;
import java.util.Map;

public abstract class GroceryReceiptBase {
    private Map<String, Double> prices;
    private Map<String, Integer> discounts;
    
    
	public GroceryReceiptBase(Map<String, Double> prices, Map<String, Integer> discounts) {
		super();
		this.prices = prices;
		this.discounts = discounts;
	}
    
    public abstract List<Grocery> Calculate(List<Node> shoppingList);

	public Map<String, Double> getPrices() {
		return prices;
	}

	public void setPrices(Map<String, Double> prices) {
		this.prices = prices;
	}

	public Map<String, Integer> getDiscounts() {
		return discounts;
	}

	public void setDiscounts(Map<String, Integer> discounts) {
		this.discounts = discounts;
	}

    
    
    
    
}
