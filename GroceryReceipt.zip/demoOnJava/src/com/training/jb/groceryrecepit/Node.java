package com.training.jb.groceryrecepit;

public class Node {
	
    String fruit;
    int count;
    
    
	public Node(String fruit, int count) {
		super();
		this.fruit = fruit;
		this.count = count;
	}
    
    


}
