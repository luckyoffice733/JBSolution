package com.training.jb.groceryrecepit;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class GroceryReceipt extends GroceryReceiptBase {

	public GroceryReceipt(Map<String, Double> prices, Map<String, Integer> discounts) {
		super(prices, discounts);
	}

	@Override
	public List<Grocery> Calculate(List<Node> shoppingList) {
        Map<String, Integer> list=new TreeMap<>();
        for(Node node: shoppingList){
            // String fruit=node.fruit;
            // int sum=node.fruit;

            // list.merge(fruit, sum, Integer::sum);
            list.merge(node.fruit, node.count, Integer::sum);
        }

        List<Grocery> finalPrice=new ArrayList<>();
        
        for(Map.Entry<String, Integer> groDis: list.entrySet()){
           // finalPrice.add(new Grocery(fruit, price, total));
        }return finalPrice;
    }

	

}
