package com.training.jb.movielibrary;

public class Film implements IFilm{
	
	String title;
	String director;
	int year;

	@Override
	public void setTitle(String title) {
		// TODO Auto-generated method stub
		this.title=title;
	}

	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return this.title;
	}

	@Override
	public void setDirector(String director) {
		// TODO Auto-generated method stub
		this.director=director;
	}

	@Override
	public String getDirector() {
		// TODO Auto-generated method stub
		return this.director;
	}

	@Override
	public void setYear(int year) {
		// TODO Auto-generated method stub
		this.year=year;
	}

	@Override
	public int getYear() {
		// TODO Auto-generated method stub
		return this.year;
	}

	
    @Override
    public String toString(){
        return title + "(" + director + "," + year + ")";
    }

	
}
