package com.training.jb.movielibrary;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        //PrintWriter out = new PrintWriter(System.out);

        IFilmLibrary filmLibrary = new FilmLibrary();
        List<IFilm> films = new ArrayList<>();
        int fCount = Integer.parseInt(br.readLine().trim());

        for (int i = 0; i < fCount; i++) {
            String[] a = br.readLine().trim().split(" ");
            IFilm e = new Film();
            e.setTitle(a[0]);
            e.setDirector(a[1]);
            e.setYear(Integer.parseInt(a[2]));
    //System.out.println("we are in forloop");
            filmLibrary.addFilm(e);
            films.add(e);
        }
  
        
        int totalFilmCount = filmLibrary.getTotalFilmCount();
        System.out.println("Total Film Count: " + totalFilmCount);

        String[] b = br.readLine().trim().split(" ");
        String query = b[0];
        List<IFilm> searchResults = filmLibrary.searchFilms(query);

       System.out.println("Search Results for " + query + ":");
        for (IFilm film : searchResults) {
            System.out.println(film.getTitle() + " (" + film.getDirector() + ", " + film.getYear() + ")");
        }

        String[] c = br.readLine().trim().split(" ");
        String title = c[0];
        IFilm randomFilm = null;

        for (IFilm film : films) {
            if (film.getTitle().equals(title)) {
                randomFilm = film;
                break;
            }
        }

        if (randomFilm != null) {
            filmLibrary.removeFilm(randomFilm.getTitle());
            System.out.println("Removed Film: " + randomFilm.getTitle() + " (" + randomFilm.getDirector() + ", " + randomFilm.getYear() + ")");
        }

        List<IFilm> allFilms = filmLibrary.getFilms();
        System.out.println("All Films:");
        for (IFilm film : allFilms) {
            System.out.println(film.getTitle() + " (" + film.getDirector() + ", " + film.getYear() + ")");
        }

		/*
		 * out.flush(); out.close();
		 */
    }

}
