package com.training.jb.movielibrary;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class FilmLibrary implements IFilmLibrary{
  
	List<IFilm> ll = new ArrayList<>();
	
	@Override
	public void addFilm(IFilm film) {
		// TODO Auto-generated method stub
		ll.add(film);
	}

	@Override
	public void removeFilm(String title) {
		// TODO Auto-generated method stub
	Iterator<IFilm> iobj=	ll.iterator();
		while(iobj.hasNext()) {
			IFilm fm =iobj.next();
			if(fm.getTitle().equals(title)) {
				iobj.remove();
			}
		}
		
	}

	@Override
	public List<IFilm> getFilms() {
		// TODO Auto-generated method stub
		return  ll;
	}

	@Override
	public List<IFilm> searchFilms(String query) {
		// TODO Auto-generated method stub
		List<IFilm> sf = new ArrayList<>();
		
		for(IFilm fm:ll) {
			if(fm.getTitle().equals(query) || fm.getDirector().equals(query)) {
				sf.add(fm);
			}
		}
		return sf;
	}

	@Override
	public int getTotalFilmCount() {
		// TODO Auto-generated method stub
		return ll.size();
			
	}

}
